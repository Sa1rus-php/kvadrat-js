<?php
include 'func.php';
echo Txt($_GET['file']);