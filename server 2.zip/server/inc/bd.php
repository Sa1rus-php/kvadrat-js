<?php
$dsn = 'mysql:dbname=kyrsi;host=kyrs_mysql';
$user = 'root';
$password = 'bfigf_iee-bifjb';
$bd = new PDO($dsn, $user, $password);